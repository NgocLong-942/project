from tkinter import *
import login

#main method
def main():
    root = Tk()
    root.title("Repair Reporting System")
    # root.geometry("1400x930+100+50")
    root.geometry("1920x1080")
    root.resizable(False, True)

    login.Login(root)

    root.mainloop()

if __name__ == '__main__':
    main()
