import sqlite3
class Database:
    def __init__(self, db):
        #
        self.con = sqlite3.connect(db)
        self.cur = self.con.cursor()
        #
        sql = """
        CREATE TABLE IF NOT EXISTS users (
            userID INTEGER PRIMARY KEY,
            name TEXT,
            idstaff TEXT,
            position TEXT,
            username TEXT,
            password TEXT
        )
        """
        sql2 = """
        CREATE TABLE IF NOT EXISTS cisco48 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql4 = """
        CREATE TABLE IF NOT EXISTS cisco8 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql3 = """
        CREATE TABLE IF NOT EXISTS diw377 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql5 = """
        CREATE TABLE IF NOT EXISTS r650 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql6 = """
        CREATE TABLE IF NOT EXISTS revlon13 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql7 = """
        CREATE TABLE IF NOT EXISTS revlon24 (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql8 = """
        CREATE TABLE IF NOT EXISTS si (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        sql9 = """
        CREATE TABLE IF NOT EXISTS usw (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        self.cur.execute(sql)
        self.cur.execute(sql2)
        self.cur.execute(sql3)
        self.cur.execute(sql4)
        self.cur.execute(sql5)
        self.cur.execute(sql6)
        self.cur.execute(sql7)
        self.cur.execute(sql8)
        self.cur.execute(sql9)
        self.con.commit()
    """Admin Controls - Backend"""
    #
    def insertInstructor(self, name, position, idstaff, username, password):
        self.cur.execute("INSERT INTO users VALUES (NULL,?,?,?,?,?)",
                         (name, position, idstaff, username, password))
        self.con.commit()
    #
    def viewInstructor(self):
        self.cur.execute("SELECT * FROM users")
        rows = self.cur.fetchall()
        return rows
    #
    def removeInstructor(self, insID):
        self.cur.execute("DELETE FROM users WHERE userID=?", (insID,))
        self.con.commit()
    #
    def editInstructor(self, insID, name, position, idstaff, username, password):
        sql_insert_query = """UPDATE instructors SET name=?, position=?, idstaff=?, username=?, password=? WHERE userID=?"""
        self.cur.execute(sql_insert_query, (name, position, idstaff, username, password, insID))
        self.con.commit()
    """Instructor Controls - Backend"""
    #
    def insertReportDiw377(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                     remark,  project):
        self.cur.execute("INSERT INTO diw377 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (
                         station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project))
        self.con.commit()
    #
    def viewReportDiw377(self):
        self.cur.execute("SELECT * FROM diw377")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportDiw377(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                   remark):
        sql_update_query = """
        UPDATE diw377 
        SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
        WHERE rpID=?
        """
        self.cur.execute(sql_update_query,
                         (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri, remark,
                          rpID))
        self.con.commit()
    #
    def removeReportDiw377(self, rpID):
        self.cur.execute("DELETE FROM diw377 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportCisco48(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                     remark,  project):
        self.cur.execute("INSERT INTO cisco48 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (
                         station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project))
        self.con.commit()
    #
    def viewReportCisco48(self):
        self.cur.execute("SELECT * FROM cisco48")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportCisco48(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                   remark):
        sql_update_query = """
        UPDATE cisco48 
        SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
        WHERE rpID=?
        """
        self.cur.execute(sql_update_query,
                         (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri, remark,
                          rpID))
        self.con.commit()
    #
    def removeReportCisco48(self, rpID):
        self.cur.execute("DELETE FROM cisco48 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportCisco8(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                     remark,  project):
        self.cur.execute("INSERT INTO cisco8 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (
                         station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project))
        self.con.commit()
    #
    def viewReportCisco8(self):
        self.cur.execute("SELECT * FROM cisco8")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportCisco8(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                   remark):
        sql_update_query = """
        UPDATE cisco8 
        SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
        WHERE rpID=?
        """
        self.cur.execute(sql_update_query,
                         (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri, remark,
                          rpID))
        self.con.commit()
    #
    def removeReportCisco8(self, rpID):
        self.cur.execute("DELETE FROM cisco8 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportR650(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                               remark, project):
        self.cur.execute("INSERT INTO r650 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (
                                 station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark,
                                 project))
        self.con.commit()
    #
    def viewReportR650(self):
        self.cur.execute("SELECT * FROM r650")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportR650(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue,
                             action, dri, remark):
        sql_update_query = """
            UPDATE r650 
            SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
            WHERE rpID=?
            """
        self.cur.execute(sql_update_query,
                             (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                              remark, rpID))
        self.con.commit()
    #
    def removeReportR650(self, rpID):
        self.cur.execute("DELETE FROM r650 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportRevlon13(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                               remark, project):
        self.cur.execute("INSERT INTO revlon13 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (
                                 station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark,
                                 project))
        self.con.commit()
    #
    def viewReportRevlon13(self):
        self.cur.execute("SELECT * FROM revlon13")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportRevlon13(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue,
                             action, dri, remark):
        sql_update_query = """
            UPDATE revlon13 
            SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
            WHERE rpID=?
            """
        self.cur.execute(sql_update_query,
                             (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                              remark, rpID))
        self.con.commit()
    #
    def removeReportRevlon13(self, rpID):
        self.cur.execute("DELETE FROM revlon13 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportRevlon24(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                               remark, project):
        self.cur.execute("INSERT INTO revlon24 VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (
                                 station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark,
                                 project))
        self.con.commit()
    #
    def viewReportRevlon24(self):
        self.cur.execute("SELECT * FROM revlon24")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportRevlon24(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue,
                             action, dri, remark):
        sql_update_query = """
            UPDATE revlon24 
            SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
            WHERE rpID=?
            """
        self.cur.execute(sql_update_query,
                             (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                              remark, rpID))
        self.con.commit()
    #
    def removeReportRevlon24(self, rpID):
        self.cur.execute("DELETE FROM revlon24 WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportSI(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                               remark, project):
        self.cur.execute("INSERT INTO si VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (
                                 station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark,
                                 project))
        self.con.commit()
    #
    def viewReportSI(self):
        self.cur.execute("SELECT * FROM si")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportSI(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue,
                             action, dri, remark):
        sql_update_query = """
            UPDATE si 
            SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
            WHERE rpID=?
            """
        self.cur.execute(sql_update_query,
                             (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                              remark, rpID))
        self.con.commit()
    #
    def removeReportSI(self, rpID):
        self.cur.execute("DELETE FROM si WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def insertReportUSW(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                               remark, project):
        self.cur.execute("INSERT INTO usw VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (
                                 station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark,
                                 project))
        self.con.commit()
    #
    def viewReportUSW(self):
        self.cur.execute("SELECT * FROM usw")
        rows = self.cur.fetchall()
        return rows
    #
    def editReportUSW(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue,
                             action, dri, remark):
        sql_update_query = """
            UPDATE usw 
            SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
            WHERE rpID=?
            """
        self.cur.execute(sql_update_query,
                             (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                              remark, rpID))
        self.con.commit()
    #
    def removeReportUSW(self, rpID):
        self.cur.execute("DELETE FROM usw WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def instructorLogin(self, username, password):
        sql_select_query = "SELECT * FROM users WHERE username=? AND password=?"
        self.cur.execute(sql_select_query, (username, password))
        result = self.cur.fetchall()
        return result
    #
