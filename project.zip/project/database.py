import sqlite3
class Database:
    def __init__(self, db):
        #
        self.con = sqlite3.connect(db)
        self.cur = self.con.cursor()
        #
        sql = """
        CREATE TABLE IF NOT EXISTS instructors (
            instructorID INTEGER PRIMARY KEY,
            name TEXT,
            idstaff TEXT,
            position TEXT,
            username TEXT,
            password TEXT
        )
        """
        sql3 = """
        CREATE TABLE IF NOT EXISTS reports (
            rpID INTEGER PRIMARY KEY,
            station TEXT,
            shift TEXT,
            issue TEXT,
            date TEXT,
            line TEXT,
            starttime TEXT,
            endtime TEXT,
            losetime TEXT,
            action TEXT,
            dri TEXT,
            remark TEXT,
            project TEXT
        )
        """
        self.cur.execute(sql)
        self.cur.execute(sql3)
        self.con.commit()
    """Admin Controls - Backend"""
    #
    def insertInstructor(self, name, position, idstaff, username, password):
        self.cur.execute("INSERT INTO instructors VALUES (NULL,?,?,?,?,?)",
                         (name, position, idstaff, username, password))
        self.con.commit()
    #
    def viewInstructor(self):
        self.cur.execute("SELECT * FROM instructors")
        rows = self.cur.fetchall()
        return rows
    #
    def removeInstructor(self, insID):
        self.cur.execute("DELETE FROM instructors WHERE instructorID=?", (insID,))
        self.con.commit()
    #
    def editInstructor(self, insID, name, position, idstaff, username, password):
        sql_insert_query = """UPDATE instructors SET name=?, position=?, idstaff=?, username=?, password=? WHERE instructorID=?"""
        self.cur.execute(sql_insert_query, (name, position, idstaff, username, password, insID))
        self.con.commit()
    """Instructor Controls - Backend"""
    #
    def insertReport(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri,
                     remark,  project):
        self.cur.execute("INSERT INTO reports VALUES (NULL,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (
                         station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project))
        self.con.commit()
    #
    def viewReport(self):
        self.cur.execute("SELECT * FROM reports")
        rows = self.cur.fetchall()
        return rows
    #
    def editReport(self, rpID, station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri,
                   remark):
        sql_update_query = """
        UPDATE reports 
        SET station=?, project=?, shift=?, date=?, line=?, starttime=?, endtime=?, losetime=?, issue=?, action=?, dri=?, remark=? 
        WHERE rpID=?
        """
        self.cur.execute(sql_update_query,
                         (station, project, shift, date, line, starttime, endtime, losetime, issue, action, dri, remark,
                          rpID))
        self.con.commit()
    #
    def removeReport(self, rpID):
        self.cur.execute("DELETE FROM reports WHERE rpID=?", (rpID,))
        self.con.commit()
    #
    def instructorLogin(self, username, password):
        sql_select_query = "SELECT * FROM instructors WHERE username=? AND password=?"
        self.cur.execute(sql_select_query, (username, password))
        result = self.cur.fetchall()
        return result
    #
