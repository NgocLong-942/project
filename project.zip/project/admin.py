from tkinter import *
from tkinter import ttk
from database import Database
from tkinter import messagebox
import login
import instructor
#
db = Database("1.db")
class AdminControls:
    def __init__(self, root):
        self.root = root
        #
        self.Name = StringVar()
        self.IdStaff = StringVar()
        self.Position = StringVar()
        self.uName = StringVar()
        self.pw = StringVar()
        #
        self.adminControlsFrame()
        self.adminFrameButtons()
        self.tableOutputFrame()
    def adminControlsFrame(self):
        #
        self.entriesFrame = Frame(self.root, bg="#5856a0")
        self.entriesFrame.pack(side=TOP, fill=X)
        self.admin_frame_title = Label(self.entriesFrame, text="Admin Control Panel", font=("Goudy old style", 35),
                                       bg="#5856a0",
                                       fg="white")
        self.admin_frame_title.grid(row=0, columnspan=2, padx=10, pady=20, sticky="w")
        #
        self.labelName = Label(self.entriesFrame, text="Name", font=("Times New Roman", 16, "bold"), bg="#5856a0",
                               fg="white")
        self.labelName.grid(row=5, column=0, padx=10, pady=5, sticky="w")
        self.txtName = Entry(self.entriesFrame, textvariable=self.Name, font=("Times New Roman", 15), width=30)
        self.txtName.grid(row=5, column=1, padx=10, pady=5, sticky="w")
        #
        self.labelIdStaff = Label(self.entriesFrame, text="IdStaff", font=("Times New Roman", 16, "bold"), bg="#5856a0",
                                 fg="white")
        self.labelIdStaff.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.txtIdStaff = Entry(self.entriesFrame, textvariable=self.IdStaff, font=("Times New Roman", 15), width=30)
        self.txtIdStaff.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        #
        self.labelPosition = Label(self.entriesFrame, text="Position", font=("Times New Roman", 16, "bold"),
                                 bg="#5856a0",
                                 fg="white")
        self.labelPosition.grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.comboPosition = ttk.Combobox(self.entriesFrame, textvariable=self.Position, font=("Times New Roman", 15),
                                       width=28,
                                       state="readonly")
        self.comboPosition['values'] = ("IDL", "DL")
        self.comboPosition.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        #
        self.labelUsername = Label(self.entriesFrame, text="Username", font=("Times New Roman", 16, "bold"),
                                   bg="#5856a0",
                                   fg="white")
        self.labelUsername.grid(row=3, column=0, padx=10, pady=5, sticky="w")
        self.txtUsername = Entry(self.entriesFrame, textvariable=self.uName, font=("Times New Roman", 15), width=30,
                                 bg="#D3D3E7")
        self.txtUsername.grid(row=3, column=1, padx=10, pady=5, sticky="w")
        #
        self.labelPassword = Label(self.entriesFrame, text="Password", font=("Times New Roman", 16, "bold"),
                                   bg="#5856a0",
                                   fg="white")
        self.labelPassword.grid(row=4, column=0, padx=10, pady=5, sticky="w")
        self.txtPassword = Entry(self.entriesFrame, textvariable=self.pw, font=("Times New Roman", 15), width=30,
                                 bg="#D3D3E7")
        self.txtPassword.grid(row=4, column=1, padx=10, pady=5, sticky="w")
    """Sub Methods to be used in primary CTA methods"""
    def getData(self, event):
        try:
            self.selectedRow = self.out.focus()
            self.selectedData = self.out.item(self.selectedRow)
            self.chosenRow = self.selectedData["values"]
            self.Name.set(self.chosenRow[1])
            self.Position.set(self.chosenRow[3])
            self.IdStaff.set(self.chosenRow[2])
            self.uName.set(self.chosenRow[4])
            self.pw.set(self.chosenRow[5])
        except IndexError as error:
            pass
    #
    def addInstructor(self):
        if self.txtName.get() == "" or self.comboPosition.get() == "" or self.txtIdStaff.get() == "" or self.txtUsername.get() == "" or self.txtPassword.get() == "":
            messagebox.showerror("Error!", "Please fill all the fields!")
            return
        db.insertInstructor(self.txtName.get(),
                            self.comboPosition.get(),
                            self.txtIdStaff.get(),
                            self.txtUsername.get(),
                            self.txtPassword.get())
        messagebox.showinfo("Success!", "Record Successfully Insertered!")
        self.resetForm()
        self.viewInstructor()
    #
    def assignInstructor(self):
        if self.txtName.get() == "" or self.comboPosition.get() == "" or  self.txtIdStaff.get() == "" or self.txtUsername.get() == "" or self.txtPassword.get() == "":
            messagebox.showerror("Error!", "Choose an User to Update Details!")
            return
        #
        try:
            db.editInstructor(self.chosenRow[0],
                              self.txtName.get(),
                              self.comboPosition.get(),
                              self.txtIdStaff.get(),
                              self.txtUsername.get(),
                              self.txtPassword.get())
            messagebox.showinfo("Success!", "Record Successfully Updated!")
            self.resetForm()
            self.viewInstructor()
        except AttributeError as error:
            messagebox.showerror("Error!", "Choose an existing User to Update Details")
    #
    def dltInstructor(self):
        try:
            db.removeInstructor(self.chosenRow[0])
            self.resetForm()
            self.viewInstructor()
        except AttributeError as error:
            messagebox.showerror("Error!", "Please Choose an User Record to Remove!")
    #
    def viewInstructor(self):
        self.out.delete(*self.out.get_children())
        for row in db.viewInstructor():
            self.out.insert("", END, values=row)
    #
    def resetForm(self):
        self.Name.set("")
        self.IdStaff.set("")
        self.Position.set("")
        self.uName.set("")
        self.pw.set("")
    def manageReport(self):
        self.entriesFrame.destroy()
        self.buttonsFrame.destroy()
        self.tableFrame.destroy()
        instructor.InstructorControls(self.root)
    #
    def logOut(self):
        self.entriesFrame.destroy()
        self.buttonsFrame.destroy()
        self.tableFrame.destroy()
        login.Login(self.root)
    #
    def adminFrameButtons(self):
        #
        self.buttonsFrame = Frame(self.entriesFrame, bg="#5856a0")
        self.buttonsFrame.grid(row=10, column=0, padx=10, pady=10, sticky="w", columnspan=8)
        #
        self.btnAdd = Button(self.buttonsFrame, command=self.addInstructor, text="Add User", bd=0, cursor="hand2",
                             bg="#EADDF7",
                             fg="#5856a0", width=20, font=("Impact", 15))
        self.btnAdd.grid(row=0, column=0, padx=10)
        #
        self.btnUpdate = Button(self.buttonsFrame, command=self.assignInstructor, text="Update User", bd=0,
                                cursor="hand2",
                                bg="#EADDF7",
                                fg="#5856a0", width=20, font=("Impact", 15))
        self.btnUpdate.grid(row=0, column=1, padx=10)
        #
        self.btnDlt = Button(self.buttonsFrame, command=self.dltInstructor, text="Remove User", bd=0,
                             cursor="hand2",
                             bg="#EADDF7",
                             fg="#5856a0", width=20, font=("Impact", 15))
        self.btnDlt.grid(row=0, column=2, padx=10)
        #
        self.btnReset = Button(self.buttonsFrame, command=self.resetForm, text="Reset Form", bd=0, cursor="hand2",
                               bg="#EADDF7", fg="#5856a0", width=20, font=("Impact", 15))
        self.btnReset.grid(row=0, column=3, padx=10)
        #
        self.btnView = Button(self.buttonsFrame, command=self.viewInstructor, text="View User List", bd=0,
                              cursor="hand2",
                              bg="#EADDF7",
                              fg="#5856a0", width=20, font=("Impact", 15))
        self.btnView.grid(row=0, column=4, padx=10)
        #
        self.btnmanageReport = Button(self.buttonsFrame, command=self.manageReport, text="Manage Report", bd=0,
                                    cursor="hand2",
                                    bg="#EADDF7", fg="#5856a0", width=20, font=("Impact", 15))
        self.btnmanageReport.grid(row=0, column=5, padx=10)
        #
        self.btnLogOut = Button(self.entriesFrame, command=self.logOut, text="Log Out", bd=0, cursor="hand2",
                                bg="#EADDF7",
                                fg="#5856a0", width=15, font=("Impact", 15))
        self.btnLogOut.grid(row=0, column=7, padx=15, sticky="e")
    def tableOutputFrame(self):
        #
        self.tableFrame = Frame(self.root, bg="#DADDE6")
        self.tableFrame.place(x=0, y=350, width=1600, height=560)
        self.yScroll = Scrollbar(self.tableFrame)
        self.yScroll.pack(side=RIGHT, fill=Y)
        #
        self.style = ttk.Style()
        self.style.configure("mystyle.Treeview", font=('Calibri', 12),
                             rowheight=50)
        self.style.configure("mystyle.Treeview.Heading", font=('Times New Roman', 14, "bold"), sticky="w")
        #
        self.out = ttk.Treeview(self.tableFrame, yscrollcommand=self.yScroll.set,
                                columns=(1, 2, 3, 4, 5, 6), style="mystyle.Treeview")
        self.out.heading("1", text="Index")
        self.out.column("1", width=10)
        self.out.heading("2", text="Name")
        self.out.column("2", width=30)
        self.out.heading("3", text="IdStaff")
        self.out.column("3", width=10)
        self.out.heading("4", text="Position")
        self.out.column("4", width=10)
        self.out.heading("5", text="Username")
        self.out.column("5", width=10)
        self.out.heading("6", text="Password")
        self.out.column("6", width=10)
        self.out['show'] = 'headings'
        #
        self.out.bind("<ButtonRelease-1>", self.getData)
        #
        self.out.pack(fill=X)
        self.yScroll.config(command=self.out.yview)
