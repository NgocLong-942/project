import json
from flask import Flask, jsonify, request

app = Flask(__name__)

users = [
    { 'id': 1, 'name': 'Ashley', 'username' : 'a' , 'password' : 'a' , 'position' : 'a', 'idstaff' : 'V1234567' }
]
nextUserId = 2

@app.route('/user', methods=['GET'])
def get_user():
    return jsonify(users)

@app.route('/user/<int:id>', methods=['GET'])
def get_user_by_id(id: int):
    user = next((e for e in users if e['id'] == id), None)
    if user is None:
        return jsonify({ 'error': 'user does not exist'}), 404
    return jsonify(user)

def user_is_valid(user):
    required_fields = {'name', 'username', 'password', 'position', 'idstaff'}
    return required_fields.issubset(user.keys())

@app.route('/create-user', methods=['POST'])
def create_user():
    global nextUserId
    user = json.loads(request.data)
    if not user_is_valid(user):
        return jsonify({ 'error': 'Invalid user properties.' }), 400
    user['id'] = nextUserId
    nextUserId += 1
    users.append(user)
    return '', 201, { 'location': f'/user/{user["id"]}' }

@app.route('/update-user/<int:id>', methods=['PUT'])
def update_employee(id: int):
    user = next((e for e in users if e['id'] == id), None)
    if user is None:
        return jsonify({ 'error': 'user does not exist.' }), 404
    updated_user = json.loads(request.data)
    if not user_is_valid(updated_user):
        return jsonify({ 'error': 'Invalid user properties.' }), 400
    user.update(updated_user)
    return jsonify(user)

@app.route('/delete-user/<int:id>', methods=['DELETE'])
def delete_user(id: int):
    global users
    user = next((e for e in users if e['id'] == id), None)
    if user is None:
        return jsonify({ 'error': 'user does not exist.' }), 404
    users = [e for e in users if e['id'] != id]
    return jsonify(user), 200

if __name__ == '__main__':
    app.run(port=5000)
