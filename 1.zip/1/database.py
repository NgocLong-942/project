import mysql.connector
from mysql.connector import Error

class Database:
    def __init__(self, host, user, password, database):
        try:
            # Kết nối tới cơ sở dữ liệu
            self.con = mysql.connector.connect(
                host=host,
                user=user,
                password=password,
                database=database
            )
            self.cur = self.con.cursor()

        except Error as e:
            print(f"Error: {e}")
            self.cur = None
    
    def insertInstructor(self, name, position, idstaff, username, password):
        query = """
        INSERT INTO users (name, position, idstaff, username, password)
        VALUES (%s, %s, %s, %s, %s)
        """
        values = (name, position, idstaff, username, password)
        self.cur.execute(query, values)
        self.con.commit()
    
    def editInstructor(self, userID, name, position, idstaff, username, password):
        query = """
        UPDATE users
        SET name = %s, position = %s, idstaff = %s, username = %s, password = %s
        WHERE userID = %s
        """
        values = (name, position, idstaff, username, password, userID)
        self.cur.execute(query, values)
        self.con.commit()
    
    def removeReportUSW(self, userID):
        query = "DELETE FROM users WHERE userID = %s"
        self.cur.execute(query, (userID,))
        self.con.commit()
    
    def viewInstructor(self):
        query = "SELECT * FROM users"
        self.cur.execute(query)
        return self.cur.fetchall()

    def instructorLogin(self, username, password):
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        self.cur.execute(query, (username, password))
        result = self.cur.fetchone()
        return result is not None
