import mysql.connector
from mysql.connector import Error

class Database:
    def __init__(self, host, user, password, database):
        try:
            # Kết nối tới cơ sở dữ liệu
            self.con = mysql.connector.connect(
                host=host,
                user=user,
                password=password,
                database=database
            )
            self.cur = self.con.cursor()

        except Error as e:
            print(f"Error: {e}")
            self.cur = None
    # User --------------------------------------------------------------------
    def insertUser(self, name, position, idstaff, username, password):
        query = """
        INSERT INTO users (name, position, idstaff, username, password)
        VALUES (%s, %s, %s, %s, %s)
        """
        values = (name, position, idstaff, username, password)
        self.cur.execute(query, values)
        self.con.commit()
    
    def editUser(self, id, name, position, idstaff, username, password):
        query = """
        UPDATE users
        SET name = %s, position = %s, idstaff = %s, username = %s, password = %s
        WHERE id = %s
        """
        values = (name, position, idstaff, username, password, id)
        self.cur.execute(query, values)
        self.con.commit()
    
    def removeUser(self, id):
        query = "DELETE FROM users WHERE id = %s"
        self.cur.execute(query, (id,))
        self.con.commit()
    
    def viewUser(self):
        query = "SELECT * FROM users"
        self.cur.execute(query)
        return self.cur.fetchall()
    # Cisco 48 ------------------------------------------------------------------
    def insertReportCisco48(self, station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project):
        query = """
        INSERT INTO cisco48 (station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project)
        self.cur.execute(query, values)
        self.con.commit()

    def editReportCisco48(self, rpID, station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project):
        query = """
        UPDATE cisco48
        SET station = %s, shift = %s, issue = %s, date = %s, line = %s, starttime = %s, 
            endtime = %s, losetime = %s, action = %s, dri = %s, remark = %s, project = %s
        WHERE rpID = %s
        """
        values = (station, shift, issue, date, line, starttime, endtime, losetime, action, dri, remark, project, rpID)
        self.cur.execute(query, values)
        self.con.commit()

    def removeReportCisco48(self, rpID):
        query = "DELETE FROM cisco48 WHERE rpID = %s"
        self.cur.execute(query, (rpID,))
        self.con.commit()

    def viewReportCisco48(self):
        query = "SELECT * FROM cisco48"
        self.cur.execute(query)
        return self.cur.fetchall()

    def UserLogin(self, username, password):
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        self.cur.execute(query, (username, password))
        result = self.cur.fetchone()
        return result is not None


# CREATE TABLE IF NOT EXISTS cisco48 (
#             rpID INT AUTO_INCREMENT PRIMARY KEY,
#             station VARCHAR(255),
#             shift VARCHAR(50),
#             issue VARCHAR(255),
#             date DATE,
#             line VARCHAR(50),
#             starttime TIME,
#             endtime TIME,
#             losetime TIME,
#             action TEXT,
#             dri VARCHAR(255),
#             remark TEXT,
#             project VARCHAR(255)
#         )