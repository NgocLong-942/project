from tkinter import *
from tkinter import messagebox
import admin
import select

from database import Database

my_db = Database(
    host="localhost",  # Thay đổi nếu host không phải localhost
    user="root",  # Username của MySQL
    password="",  # Password MySQL (để trống nếu chưa thiết lập)
    database="project"  # Tên cơ sở dữ liệu bạn đã tạo
)

class Login:
    def __init__(self, root):
        self.login_frame_title = None
        self.root = root
        self.username = StringVar()
        self.password = StringVar()

        self.root.config(bg="#ADD8E6")
        self.loginControlFrame()

    """CTA Methods"""

    def loginFunc(self):
        if self.txtUsername.get() == 'admin' and self.txtPassword.get() == 'admin':
            self.loginFrame.destroy()
            admin.AdminControls(self.root)
        elif my_db.UserLogin(self.txtUsername.get(), self.txtPassword.get()):
            self.loginFrame.destroy()
            select.Select(self.root)
        else:
            messagebox.showerror("Error!", "Check your credentials or Please Contact System Admin!")
            self.username.set("")
            self.password.set("")
    """Login Frame"""

    def loginControlFrame(self):
        self.loginFrame = Frame(self.root, bg="white")
        self.loginFrame.pack(side=LEFT, fill=X, padx=100)

        self.login_frame_title = Label(self.loginFrame, text="Login Here", font=("Times New Roman", 35), bg="white",
                                       fg="#5856a0")
        self.login_frame_title.grid(row=0, columnspan=2, padx=10, pady=20, sticky="w")

        self.labelUsername = Label(self.loginFrame, text="Username", font=("Times New Roman", 16, "bold"), bg="white",
                                   fg="#5856a0")
        self.labelUsername.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.txtUsername = Entry(self.loginFrame, textvariable=self.username, font=("Times New Roman", 15), width=30,
                                 bd=5)
        self.txtUsername.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        self.labelPassword = Label(self.loginFrame, text="Password", font=("Times New Roman", 16, "bold"), bg="white",
                                   fg="#5856a0")
        self.labelPassword.grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.txtPassword = Entry(self.loginFrame, textvariable=self.password, font=("Times New Roman", 15), width=30,
                                 bd=5, show="*")
        self.txtPassword.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        self.btnLogin = Button(self.loginFrame, command=self.loginFunc, text="Login", bd=0, cursor="hand2", fg="white",
                               bg="#5856a0", width=10, font=("Times New Roman", 15))
        self.btnLogin.grid(row=3, column=1, padx=10, sticky="e")

        self.emptyLabel = Label(self.loginFrame, font=("Times New Roman", 16, "bold"), bg="white", fg="#5856a0")
        self.emptyLabel.grid(row=4, column=1, padx=10, pady=5, sticky="w")

