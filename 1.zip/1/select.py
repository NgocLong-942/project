from tkinter import *
import R650
import DIW377
import Cisco8
import Cisco48
import Revlon13
import Revlon24
import SomersetInfra
import USW

class Select:
    def __init__(self, root):
        self.root = root
        self.show_attribute_selection()

    def show_attribute_selection(self):
        self.attributeFrame = Frame(self.root, bg="white")
        self.attributeFrame.pack(side=LEFT, fill=X, padx=100)

        self.attribute_frame_title = Label(self.attributeFrame, text="Select Project", font=("Times New Roman", 35),
                                           bg="white", fg="#5856a0")
        self.attribute_frame_title.grid(row=0, columnspan=2, padx=10, pady=20, sticky="w")

        self.btnDIW377 = Button(self.attributeFrame, text="DIW377", bd=0, cursor="hand2", fg="white",
                                bg="#5856a0", width=20, font=("Times New Roman", 15), command=self.open_DIW377_controls)
        self.btnDIW377.grid(row=1, column=0, padx=10, pady=10)
        #
        self.btnR650 = Button(self.attributeFrame, text="R650", bd=0, cursor="hand2", fg="white",
                              bg="#5856a0", width=20, font=("Times New Roman", 15),
                              command=self.open_R650_controls)
        self.btnR650.grid(row=1, column=1, padx=10, pady=10)
        #
        self.btnCisco8 = Button(self.attributeFrame, text="Cisco-8", bd=0, cursor="hand2", fg="white",
                                bg="#5856a0", width=20, font=("Times New Roman", 15),
                                command=self.open_Cisco8_controls)
        self.btnCisco8.grid(row=1, column=2, padx=10, pady=10)
        #
        self.btnCisco48 = Button(self.attributeFrame, text="Cisco-48", bd=0, cursor="hand2", fg="white",
                                 bg="#5856a0", width=20, font=("Times New Roman", 15),
                                 command=self.open_Cisco48_controls)
        self.btnCisco48.grid(row=2, column=0, padx=10, pady=10)
        #
        self.btnRevlon24 = Button(self.attributeFrame, text="Revlon 2/4", bd=0, cursor="hand2", fg="white",
                                  bg="#5856a0", width=20, font=("Times New Roman", 15),
                                  command=self.open_Revlon24_controls)
        self.btnRevlon24.grid(row=2, column=1, padx=10, pady=10)
        #
        self.btnRevlon13 = Button(self.attributeFrame, text="Revlon 1/3", bd=0, cursor="hand2", fg="white",
                                  bg="#5856a0", width=20, font=("Times New Roman", 15),
                                  command=self.open_Revlon13_controls)
        self.btnRevlon13.grid(row=2, column=2, padx=10, pady=10)
        #
        self.btnSomersetInfra = Button(self.attributeFrame, text="Somerset Infra", bd=0, cursor="hand2", fg="white",
                                       bg="#5856a0", width=20, font=("Times New Roman", 15),
                                       command=self.open_SomersetInfra_controls)
        self.btnSomersetInfra.grid(row=2, column=3, padx=10, pady=10)
        #
        self.btnUSW = Button(self.attributeFrame, text="USW", bd=0, cursor="hand2", fg="white",
                             bg="#5856a0", width=20, font=("Times New Roman", 15),
                             command=self.open_USW_controls)
        self.btnUSW.grid(row=1, column=3, padx=10, pady=10)


    def open_DIW377_controls(self):
        self.attributeFrame.destroy()
        DIW377.InstructorControls(self.root)


    def open_R650_controls(self):
        self.attributeFrame.destroy()
        R650.InstructorControls(self.root)


    def open_Cisco8_controls(self):
        self.attributeFrame.destroy()
        Cisco8.InstructorControls(self.root)


    def open_Cisco48_controls(self):
        self.attributeFrame.destroy()
        Cisco48.InstructorControls(self.root)


    def open_Revlon24_controls(self):
        self.attributeFrame.destroy()
        Revlon24.InstructorControls(self.root)


    def open_Revlon13_controls(self):
        self.attributeFrame.destroy()
        Revlon13.InstructorControls(self.root)


    def open_SomersetInfra_controls(self):
        self.attributeFrame.destroy()
        SomersetInfra.InstructorControls(self.root)


    def open_USW_controls(self):
        self.attributeFrame.destroy()
        USW.InstructorControls(self.root)