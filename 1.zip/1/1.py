import mysql.connector
from mysql.connector import Error
import bcrypt

class Database:
    def __init__(self, host, user, password, database):
        try:
            # Kết nối tới cơ sở dữ liệu
            self.con = mysql.connector.connect(
                host=host,
                user=user,
                password=password,
                database=database
            )
            self.cur = self.con.cursor()

            # Tạo bảng (chỉ thực hiện nếu bảng chưa tồn tại)
            self.cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                userID INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255),
                idstaff VARCHAR(255),
                position VARCHAR(255),
                username VARCHAR(255) UNIQUE,
                password VARCHAR(255)
            )
            """)
            self.con.commit()
        except Error as e:
            print(f"Error: {e}")
            self.cur = None
            self.con = None

    def insert_user(self, name, idstaff, position, username, password):
        if self.con and self.cur:
            # Mã hóa mật khẩu trước khi lưu
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            query = "INSERT INTO users (name, idstaff, position, username, password) VALUES (%s, %s, %s, %s, %s)"
            values = (name, idstaff, position, username, hashed_password)
            try:
                self.cur.execute(query, values)
                self.con.commit()
            except Error as e:
                print(f"Error: {e}")
                self.con.rollback()

    def view_users(self):
        if self.con and self.cur:
            try:
                self.cur.execute("SELECT * FROM users")
                return self.cur.fetchall()
            except Error as e:
                print(f"Error: {e}")
                return []
        return []

    def remove_user(self, user_id):
        if self.con and self.cur:
            try:
                self.cur.execute("DELETE FROM users WHERE userID = %s", (user_id,))
                self.con.commit()
            except Error as e:
                print(f"Error: {e}")
                self.con.rollback()

    def close_connection(self):
        if self.con:
            self.cur.close()
            self.con.close()

# Sử dụng
if __name__ == "__main__":
    # Kết nối tới MySQL
    my_db = Database(
        host="localhost",  # Thay đổi nếu host không phải localhost
        user="root",       # Username của MySQL
        password="",       # Password MySQL (để trống nếu chưa thiết lập)
        database="project"  # Tên cơ sở dữ liệu bạn đã tạo
    )

    # Thêm một user mới
    my_db.insert_user("John Doe", "ID123", "Manager", "johndoe", "password123")

    # Xem danh sách users
    users = my_db.view_users()
    for user in users:
        print(user)

    # Đóng kết nối
    my_db.close_connection()
